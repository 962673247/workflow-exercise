package com.czhhhb.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionLook implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        //实现图书查看功能，监听实现gui 并且调用数据库操作
        //直接显示现有全部图书，信息过多要有滚动条下拉
    }
}
