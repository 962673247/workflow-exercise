package com.czhhhb.model;

public class Book {
    private String num;
    private String name;
    private String IBSN;
    public Book(String num, String name, String IBSN) {
        this.num = num;
        this.name = name;
        this.IBSN = IBSN;
    }
    public Book() {
    }
    public String getNum() {
        return num;
    }

    public void setNum(String number) {
        this.num = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIBSN() {
        return IBSN;
    }

    public void setIBSN(String IBSN) {
        this.IBSN = IBSN;
    }
}
